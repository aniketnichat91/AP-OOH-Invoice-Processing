{
  
 # Connection Code 
  title: 'Microsoft Form Recognizer',
  connection: {
    fields: [
      {
        name: "domain_name",
        hint: "Enter in the FormRec endpoint",
        optional: false,
      },
     
      {
        name: 'Ocp-Apim-Subscription-Key',
        label: 'Ocp-Apim-Subscription-Key',
        control_type: 'password',
        optional: false,
        
        hint: 'Get a subscription key through Azure Portal'
      },
    ],
    
    authorization: {
      type: 'api_key',

      apply: lambda do |connection|
        headers('Ocp-Apim-Subscription-Key': connection['Ocp-Apim-Subscription-Key'])
      end
    },
    
    base_uri: lambda do |connection|
      #puts  "base url : #{connection["domain_name"]}"
     #  puts  "sorc url : #{connection["sourcename"]}"
     "#{connection["domain_name"]}"
    end
  },
 
  test: lambda do |connection|  
   # post("#{connection['domain_name']}")
    response=post("#{connection['domain_name']}/formrecognizer/v2.1/custom/models/e2ff99ff-a424-46c1-82d4-3b4211dba47d/analyze")
    .payload('source':'https://apoohprojectstorage.blob.core.windows.net/donotdelete/invoice.pdf?sp=r&st=2023-01-12T16:44:45Z&se=2028-01-01T00:44:45Z&spr=https&sv=2021-06-08&sr=b&sig=tOCiGn29xfLfTy2Ada12fhGCesDnzVprtakieEL3FjE%3D')
    .headers('Content-Type':'application/json')
 end,
  
     #Pdf_File_Path
  methods:{
    
    #pre build model methods
  PreBuildInvoicebyURL: lambda do |connection,input|
       post("#{connection['domain_name']}/formrecognizer/v2.1/prebuilt/invoice/analyze?includeTextDetails=true")
          .payload('source': input)
          .params(pages:"1-1")
          .headers('Content-Type':'application/json')
          .after_response do |code, body, headers|
            {     
               apim_request_id:headers["apim_request_id"],
            }.to_s
      end
    end,
    
   PrebuildInvoicebyBinaryData: lambda do |connection,input|
       post("#{connection['domain_name']}/formrecognizer/v2.1/prebuilt/invoice/analyze?includeTextDetails=true")
          .headers('Content-Type':'application/pdf')
          .request_body(input.decode_base64)
          .after_response do |code, body, headers|
           {
               apim_request_id:headers["apim_request_id"],
           }.to_s
      end           
  end,
    
  
  ### 
  ### GET RESULT: PREBUILT MODEL BY BINARY
  ###
  OutputOfPrebuildInvoicebyBinaryData: lambda do |connection,input|
    
      var=call(:PrebuildInvoicebyBinaryData,{},input).slice(20,36).to_s  
      
#TK 220809-1330 increased sleep time to avoid timeout. 
sleep(20)

#TK 220809-1330 TODO: Wrap this in a Whilst block until response comes back.
      get("#{connection['domain_name']}/formrecognizer/v2.1/prebuilt/invoice/analyzeResults/"+var.to_s)
        .payload('Ocp-Apim-Subscription-Key': connection["Ocp-Apim-Subscription-Key"])
        .after_response do |code, body, headers,|
         {
           
                InvoiceId:  if   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceId")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceId"]["text"]]}.flatten.dig(0)
                             else
                                   ""
                             end,
                VendorName: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("VendorName")==true
         
                             body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["VendorName"]["text"]]}.flatten.dig(0)
                             else
                                   ""
                             end,
                AdvertiserName: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("CustomerName")==true
  
                                body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["CustomerName"]["text"]]}.flatten.dig(0)
                                  else
                                   ""
                             end,
                InvoiceDate: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceDate")==true
                                      body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceDate"]["text"]]}.flatten.dig(0)
                             end,
                InvoiceAmount: if  
                                  ( body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceTotal")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceTotal"]["text"]]}.flatten.dig(0)
         
                              else  (body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               
                               end,
                AmountDue:      if   
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               else
                                   "0" 
                               end,
               TaxAmount:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("TotalTax")==true
                                 body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["TotalTax"]["text"]] }.flatten.dig(0)
                             else
                                 "0"
                             end,
               ContractNo: "",
               To: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("CustomerAddress")==true
                    body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["CustomerAddress"]["text"]]}.flatten.dig(0)
                        else
                                 ""
                             end,        
               RemittanceAddress: if  body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]]}.to_s.include?('"RemittanceAddress"')==true
                                       body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["RemittanceAddress"]["text"]] }.flatten.dig(0)
                                   else
                                       ""
                                   end,     
               Description:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("Items")==true
                                 body["analyzeResult"]["documentResults"]
                                  .map{|fields|[fields["fields"]["Items"]["valueArray"]
                                  .map{|fields1|[fields1["valueObject"]["Description"]["text"]]}]}.flatten
                            
                             end.to_a.smart_join(","),
              TotalPages:  if   body["analyzeResult"]["documentResults"].to_s.include?("pageRange")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["pageRange"]]}
                                    .flatten.to_a.split(",").to_a.dig(0).to_a.flatten.dig(1)
                             else
                                   ""
                             end,
              
    }.each.with_index { |val,index| puts "index: #{index} for #{val}"}
   end
 end, 
    
  ### 
  ### GET RESULT: PREBUILT MODEL BY URL
  ###
 OutputOfPreBuildInvoicebyURL: lambda do |connection,input|
          var=call(:PreBuildInvoicebyURL,{},input).slice(20,36).to_s  
  puts var

#TK 220809-1330 increased sleep time to avoid timeout. 
        sleep(20)


       get("#{connection['domain_name']}/formrecognizer/v2.1/prebuilt/invoice/analyzeResults/"+var.to_s)
       .payload('Ocp-Apim-Subscription-Key': connection["Ocp-Apim-Subscription-Key"])    
       .after_response do |code, body, headers|
           {  
               #RemittanceAddress #RemittanceAddress
                InvoiceId:  if   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceId")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceId"]["text"]]}.flatten.dig(0)
                             else
                                   ""
                             end,
                VendorName: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("VendorName")==true
         
                             body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["VendorName"]["text"]]}.flatten.dig(0)
                             else
                                   ""
                             end,
                AdvertiserName: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("CustomerName")==true
  
                                body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["CustomerName"]["text"]]}.flatten.dig(0)
                                  else
                                   ""
                             end,
                InvoiceDate: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceDate")==true
                                      body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceDate"]["text"]]}.flatten.dig(0)
                             end,
                InvoiceAmount: if  
                                  ( body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceTotal")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceTotal"]["text"]]}.flatten.dig(0)
         
                              else  (body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               
                               end,
                AmountDue:      if   
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               else
                                   "0" 
                               end,
               TaxAmount:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("TotalTax")==true
                                 body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["TotalTax"]["text"]] }.flatten.dig(0)
                             else
                                 "0"
                             end,
               ContractNo: "",#if body["analyzeResult"]["pageResults"].map{|fields|[fields["tables"]] }.to_s.include?("Contract")==true
                           #     body["analyzeResult"]["pageResults"].map{|fields|[fields["tables"]] }.to_s
                          #   .include?("InvoiceTotal").flatten.dig(1).to_a.dig(2).to_a.dig(1).to_a.dig(7).to_a.dig(2).to_a.dig(1)
                          # else
                          #       ""
                         #  end,
               To: if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("CustomerAddress")==true
                    body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["CustomerAddress"]["text"]]}.flatten.dig(0)
                        else
                                 ""
                             end, 


               RemittanceAddress: if  body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]]}.to_s.include?('"RemittanceAddress"')==true
                                       body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["RemittanceAddress"]["text"]] }.flatten.dig(0)
                                   else
                                       ""
                                   end,    
               Description:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("Description")==true
                                 body["analyzeResult"]["documentResults"]
                                  .map{|fields|[fields["fields"]["Items"]["valueArray"]
                                    .map{|fields1|[fields1["valueObject"]["Description"]["text"]]}]}.flatten
                             
                               end.smart_join(","),
              TotalPages:  if   body["analyzeResult"]["documentResults"].to_s.include?("pageRange")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["pageRange"]]}
                                     .flatten.to_a.split(",").to_a.dig(0).to_a.flatten.dig(1)
                             else
                                   ""
                             end,
      }.each.with_index { |val,index| 
              puts "index : #{val}" 
    } 
   end
end, 
    
#custom model methods starts here
 CustomInvoicebyURL: lambda do |connection,input,modelid|   
      post("#{connection['domain_name']}/formrecognizer/v2.1/custom/models/"+modelid+"/analyze")
        .payload('source': input)
        .headers('Content-Type':'application/json')
        .after_response do |code, body, headers|
           {     
             operationloction:headers["operation_location"],
           }.to_s
       end
  end,


CustomInvoicebyBinaryData: lambda do |connection,input,modelid|
   post("#{connection['domain_name']}/formrecognizer/v2.1/custom/models/"+modelid+"/analyze")
       .request_body(input.decode_base64)
       .headers('Content-Type':'application/pdf')
       .after_response do |code, body, headers|
         {
           apim_request_id:headers["operation_location"],
         }.to_s
      end        
  end,

  ### 
  ### GET RESULT: CUSTOM MODEL BY URL
  ###
outputOfCustomInvoicebyURL: lambda do |connection,input,modelid|
 
      var1=call(:CustomInvoicebyURL,{},input,modelid).slice(21,179).to_s  
      puts var1

#TK 220809-1330 increased sleep time to avoid timeout. 
      sleep(20)

    get(var1)
       .payload('Ocp-Apim-Subscription-Key': connection["Ocp-Apim-Subscription-Key"])    
       .after_response do |code, body, headers|
           {  
               #RemittanceAddress #RemittanceAddress
                InvoiceId: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceId"]["text"]]}.flatten.dig(0),
                VendorName: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["VendorName"]["text"]]}.flatten.dig(0),
           
                InvoiceDate: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceDate"]["text"]]}.flatten.dig(0),               
                InvoiceAmount: if  
                                  ( body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceTotal")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceTotal"]["text"]]}.flatten.dig(0)
         
                              else  (body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               
                               end,
                AmountDue:      if   
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               else
                                   "0" 
                               end,
               TaxAmount:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("TotalTax")==true
                                 body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["TotalTax"]["text"]] }.flatten.dig(0)
                             else
                                 "0"
                             end,
               AdvertiserName: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AdvertiserName"]["text"]]}.flatten.dig(0),
               ContractNo: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["ContractNo"]["text"]]}.flatten.dig(0),
               To:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("CustomerAddress")==true
                         body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["CustomerAddress"]["text"]]}.flatten.dig(0)
                     else
                                 ""
                     end,               
               RemittanceAddress: if  body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]]}.to_s.include?("RemittanceAddress")==true
                                       body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["RemittanceAddress"]["text"]] }.flatten.dig(0)
                                   else
                                       body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["RemittanceAddress"]["text"]] }.flatten.dig(0)
                                   end,    
               Description:  
                                body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["Description"]["text"]] }.flatten.dig(0),
              TotalPages:  if   body["analyzeResult"]["documentResults"].to_s.include?("pageRange")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["pageRange"]]}
                                      .flatten.to_a.split(",").to_a.dig(0).to_a.flatten.dig(1)
                             else
                                   1
                             end,
             
      }.each.with_index { |val,index| 
              puts "index : #{val}" 
    } 
   end
end, 

  ### 
  ### GET RESULT: CUSTOM MODEL BY BINARY
  ###

 outputOfCustomInvoicebyBinaryData: lambda do |connection,input,modelid|
    var1=call(:CustomInvoicebyBinaryData,{},input,modelid).slice(20,179).to_s  
    puts var1
      sleep(20)
      get(var1.to_s)   
        .payload('Ocp-Apim-Subscription-Key': connection["Ocp-Apim-Subscription-Key"])
        .after_response do |code, body, headers,|
         {
                InvoiceId: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceId"]["text"]]}.flatten.dig(0),
                VendorName: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["VendorName"]["text"]]}.flatten.dig(0),
           
                InvoiceDate: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceDate"]["text"]]}.flatten.dig(0),               
                InvoiceAmount: if  
                                  ( body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("InvoiceTotal")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["InvoiceTotal"]["text"]]}.flatten.dig(0)
         
                              else  (body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true)
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               
                               end,
                AmountDue:      if   
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("AmountDue")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AmountDue"]["text"]] }.flatten.dig(0)
                               else
                                   "0" 
                               end,
               TaxAmount:   if  body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]]}.to_s.include?("TotalTax")==true
                                 body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["TotalTax"]["text"]] }.flatten.dig(0)
                             else
                                 "0"
                             end,
               AdvertiserName: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["AdvertiserName"]["text"]]}.flatten.dig(0),
               ContractNo: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["ContractNo"]["text"]]}.flatten.dig(0),
               To: body["analyzeResult"]["documentResults"].map{|fields|[fields["fields"]["CustomerAddress"]["text"]]}.flatten.dig(0),
                               
               RemittanceAddress: if  body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]]}.to_s.include?("RemittanceAddress")==true
                                       body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["RemittanceAddress"]["text"]] }.flatten.dig(0)
                                   else
                                       body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["RemittanceAddress"]["text"]] }.flatten.dig(0)
                                   end,    
               Description:  
                                body["analyzeResult"]["documentResults"]
                                             .map{|fields|[fields["fields"]["Description"]["text"]] }.flatten.dig(0),

              TotalPages:  if   body["analyzeResult"]["documentResults"].to_s.include?("pageRange")==true
                                   body["analyzeResult"]["documentResults"].map{|fields|[fields["pageRange"]]}
                                      .flatten.to_a.split(",").to_a.dig(0).to_a.flatten.dig(1)
                             else
                                   1
                             end,
    }.each.with_index { |val,index| puts "index: #{index} for #{val}"}   
    end           
  end,
  },
#custom model methods ends here
#method close 

#action start
  
  actions: {
  
   
    ExtractInvoicesByURL: {
      input_fields: lambda do |_object_definitions|
        [
         {
          name: "sourcename",label:"PDF URL",        
          hint: "Enter in the Blob for PDF",
          optional: false,
         },
          {
          name: 'model_type',
          control_type: 'select',
            label: "Select Type",
          pick_list: 'model_type',
            ptional: false,
             
        },
        {
          name: "model_id",
          label: "Model ID",
          type: :string,
          control_type: "text",
          ngIf:'input.model_type == "custom"',
         
        }
        ]
       end,
      
      execute: lambda do |connection,input|  
        puts 'test input  parameter values' +input['model_type']
        if input['model_type'].to_s=="pre"
               outputresult=(call(:OutputOfPreBuildInvoicebyURL,{},input['sourcename'])) #{connection['sourcename']}))
        else
               outputresult=(call(:outputOfCustomInvoicebyURL,{},input['sourcename'],input['model_id']))
        end
       end,
     output_fields: ->(object_definitions) {
        object_definitions['Invoicedetails']
      },
       
    },
    
   
    ExtractInvoicesByBinary: {
      
    input_fields: lambda do |conection|
     [
       {
        name: "File_path",label:"File Path" ,       
        hint: "Enter in the File Path, file:///C:/Users/wordpress-pdf-invoice-plugin-sample.pdf",
        optional: false,
         
       },
       {  
        name: "File_data",label:"Binary File data",        
        hint: "File should be PDF format only",
        optional: false,
       },
          {
          name: 'model_typebinary',
          control_type: 'select',
            label: "Select Type",
          pick_list: 'model_type',
            ptional: false,
             
        },
        {
          name: "model_idbinary",
          label: "Model ID",
          type: :string,
          control_type: "text",
          ngIf:'input.model_typebinary == "custom"',
         
        }
     ]
    end,
      
   execute: lambda do |connection,input|  
        puts 'test input  parameter values' +input['model_typebinary']
        if input['model_typebinary'].to_s=="pre"
               outputresult=(call(:OutputOfPrebuildInvoicebyBinaryData,{},input['File_data'])) #{connection['sourcename']}))
        else
               outputresult=(call(:outputOfCustomInvoicebyBinaryData,{},input['File_data'],input['model_idbinary']))
        end
   end,
      
    
    output_fields: ->(object_definitions) {
        object_definitions['InvoiceDetailsBinary']
      },
    }    
  },
pick_lists: {
      model_type: lambda do |connection|
        [
          ["Invoice","pre"],
          ["Custom Model","custom"],
        ]
      end
 },

object_definitions: {
    Invoicedetails: {
      fields: ->() {
        [
          { name: 'ContractNo', type: "string", label:"ContractNo" },
          { name: 'InvoiceDate', type:"string", label:"InvoiceDate" },
          { name: 'InvoiceAmount', type:"string", label:"InvoiceAmount"  },
          { name: 'AmountDue', type:"string", label:"AmountDue"  },
          { name: 'TaxAmount', type:"string", label:"TaxAmount"  },
          { name: 'To', type:"string", label:"To"  },
          { name: 'Description', type:"string", label:"Description"  },
          { name: 'AdvertiserName', type:"string", label:"Advertiser Name"  },
          { name: 'RemittanceAddress', type:"string", label:"Remittance Address"  },
          { name: 'VendorName', type:"string", label:"Vendor Name"  },
          { name: 'InvoiceId', type:"string", label:"InvoiceId"  } ,
           { name: 'TotalPages', type:"number", label:"TotalPages"  }
        ]
      },
    },
  
  InvoiceDetailsBinary: {
      fields: ->() {
        [
          { name: 'ContractNo', type: "string", label:"ContractNo" },
          { name: 'InvoiceDate', type:"string", label:"InvoiceDate" },
          { name: 'InvoiceAmount', type:"string", label:"InvoiceAmount"  },
          { name: 'AmountDue', type:"string", label:"AmountDue"  },
          { name: 'TaxAmount', type:"string", label:"TaxAmount"  },
          { name: 'To', type:"string", label:"To"  },
          { name: 'Description', type:"string", label:"Description"  },
          { name: 'AdvertiserName', type:"string", label:"Advertiser Name"  },
          { name: 'RemittanceAddress', type:"string", label:"Remittance Address"  },
          { name: 'VendorName', type:"string", label:"Vendor Name"  } ,
          { name: 'InvoiceId', type:"string", label:"InvoiceId"  },   #TotalPages
           { name: 'TotalPages', type:"number", label:"TotalPages"  }
        ]
      },
    }
        
},
}
         
